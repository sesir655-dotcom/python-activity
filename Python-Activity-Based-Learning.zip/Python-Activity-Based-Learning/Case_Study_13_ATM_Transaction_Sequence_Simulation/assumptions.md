# Assumptions

- Opening balance is ₹5,000.
- Maximum single withdrawal is ₹2,000.
- Only positive transaction amounts are accepted.
