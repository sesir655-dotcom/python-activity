# Test Case

**Input / setup:** 3 transactions: D 1000, W 2500, W 1200

**Expected output:**

```text
How many transactions? 3
Transaction 1 type (D/W): D
Amount: Rs.1000
Deposit accepted. Balance: Rs.6000.00
Transaction 2 type (D/W): W
Amount: Rs.2500
Rejected: withdrawal limit is Rs.2000.
Transaction 3 type (D/W): W
Amount: Rs.1200
Withdrawal accepted. Balance: Rs.4800.00
Accepted transactions: 2
Rejected transactions: 1
Closing balance: Rs.4800.00
```
