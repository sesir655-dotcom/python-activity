# Algorithm

1. Set the opening balance.
2. Read the number of transactions.
3. For each transaction, read type and amount.
4. Accept valid deposits; accept withdrawals only within balance and limit.
5. Display accepted/rejected transactions and closing balance.
