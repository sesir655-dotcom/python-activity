# Objectives

- Process deposits and withdrawals.
- Reject invalid amounts and withdrawals beyond available balance or the limit.
- Display a transaction summary.
