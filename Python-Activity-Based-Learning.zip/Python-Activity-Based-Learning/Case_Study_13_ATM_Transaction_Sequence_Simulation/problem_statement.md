# ATM Transaction Sequence Simulation

Process a sequence of deposits and withdrawals, maintain the account balance, enforce a withdrawal limit, and summarize transactions.
