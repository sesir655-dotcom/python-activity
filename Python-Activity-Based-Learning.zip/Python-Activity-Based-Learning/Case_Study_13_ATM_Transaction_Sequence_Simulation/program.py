balance = 5000.0
accepted = 0
rejected = 0

n = int(input("How many transactions? "))
for i in range(n):
    kind = input(f"Transaction {i + 1} type (D/W): ").strip().upper()
    amount = float(input("Amount: Rs."))
    if amount <= 0:
        print("Rejected: amount must be positive.")
        rejected += 1
    elif kind == "D":
        balance += amount
        print(f"Deposit accepted. Balance: Rs.{balance:.2f}")
        accepted += 1
    elif kind == "W":
        if amount > 2000:
            print("Rejected: withdrawal limit is Rs.2000.")
            rejected += 1
        elif amount > balance:
            print("Rejected: insufficient balance.")
            rejected += 1
        else:
            balance -= amount
            print(f"Withdrawal accepted. Balance: Rs.{balance:.2f}")
            accepted += 1
    else:
        print("Rejected: unknown transaction type.")
        rejected += 1

print(f"Accepted transactions: {accepted}")
print(f"Rejected transactions: {rejected}")
print(f"Closing balance: Rs.{balance:.2f}")
