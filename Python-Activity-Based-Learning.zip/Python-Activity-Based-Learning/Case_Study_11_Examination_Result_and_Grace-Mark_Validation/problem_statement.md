# Examination Result and Grace-Mark Validation

Process marks in several subjects, apply a limited grace-mark policy, and generate a final result without exceeding maximum marks.
