marks = []
valid = True

for i in range(5):
    mark = int(input(f"Enter marks for subject {i + 1} (0-100): "))
    if mark < 0 or mark > 100:
        print("Invalid marks. Each mark must be from 0 to 100.")
        valid = False
        break
    marks.append(mark)

if valid:
    adjusted = []
    grace_used = []
    for i, mark in enumerate(marks, start=1):
        if 30 <= mark < 35:
            needed = 35 - mark
            adjusted.append(35)
            grace_used.append((i, needed))
        else:
            adjusted.append(mark)

    print("Original marks:", marks)
    print("Final marks:", adjusted)
    if grace_used:
        print("Grace marks used:", grace_used)
    else:
        print("Grace marks used: None")

    failed = [i + 1 for i, mark in enumerate(adjusted) if mark < 35]
    if failed:
        print("Result: FAIL")
        print("Failed subject numbers:", failed)
    else:
        print("Result: PASS")
    print("Total:", sum(adjusted), "/ 500")
