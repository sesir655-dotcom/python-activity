# Assumptions

- There are five subjects, each out of 100.
- Pass mark is 35 per subject.
- At most 5 grace marks may be added to one subject that is short by no more than 5 marks.
- Grace marks cannot make a subject exceed 100.
