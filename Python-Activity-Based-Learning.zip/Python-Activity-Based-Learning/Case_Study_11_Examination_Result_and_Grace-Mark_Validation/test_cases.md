# Test Case

**Input / setup:** Marks = 78, 32, 66, 34, 90

**Expected output:**

```text
Enter marks for subject 1 (0-100): 78
Enter marks for subject 2 (0-100): 32
Enter marks for subject 3 (0-100): 66
Enter marks for subject 4 (0-100): 34
Enter marks for subject 5 (0-100): 90
Original marks: [78, 32, 66, 34, 90]
Final marks: [78, 35, 66, 35, 90]
Grace marks used: [(2, 3), (4, 1)]
Result: PASS
Total: 304 / 500
```
