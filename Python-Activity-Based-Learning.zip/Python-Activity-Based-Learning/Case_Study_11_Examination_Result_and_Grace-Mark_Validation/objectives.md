# Objectives

- Validate marks.
- Apply grace marks only under the stated policy.
- Report subject marks and pass/fail status.
