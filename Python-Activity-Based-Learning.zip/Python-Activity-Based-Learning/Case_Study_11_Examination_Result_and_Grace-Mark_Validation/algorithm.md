# Algorithm

1. Read marks for five subjects.
2. Validate each mark is between 0 and 100.
3. For a mark from 30 through 34, add only enough grace marks to reach 35.
4. Display adjusted marks and list subjects still failed.
5. Display overall result.
