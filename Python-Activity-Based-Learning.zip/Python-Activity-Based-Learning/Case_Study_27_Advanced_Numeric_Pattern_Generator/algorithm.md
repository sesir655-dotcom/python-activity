# Algorithm

1. Read the odd width.
2. Validate the width.
3. Generate the top half including the middle row.
4. Generate the bottom half in reverse.
5. Print stars only on the outline.
