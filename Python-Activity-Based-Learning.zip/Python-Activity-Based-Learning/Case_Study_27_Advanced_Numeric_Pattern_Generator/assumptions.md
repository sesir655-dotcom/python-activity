# Assumptions

- The size must be an odd integer from 3 through 19.
- The input size represents the widest row.
