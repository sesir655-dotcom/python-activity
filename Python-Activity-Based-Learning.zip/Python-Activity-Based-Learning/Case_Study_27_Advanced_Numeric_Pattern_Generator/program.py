width = int(input("Enter an odd diamond width (3-19): "))

if width < 3 or width > 19 or width % 2 == 0:
    print("Invalid width. Enter an odd number from 3 to 19.")
else:
    middle = width // 2
    for row in list(range(middle + 1)) + list(range(middle - 1, -1, -1)):
        spaces = middle - row
        if row == 0:
            print(" " * spaces + "*")
        else:
            inside = 2 * row - 1
            print(" " * spaces + "*" + " " * inside + "*")
