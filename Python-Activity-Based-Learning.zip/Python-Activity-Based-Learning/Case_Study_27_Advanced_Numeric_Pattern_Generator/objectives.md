# Objectives

- Use nested loops to generate a symmetric pattern.
- Print only the boundary stars.
- Validate the requested size.
