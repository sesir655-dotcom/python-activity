# Test Case

**Input / setup:** Width = 7

**Expected output:**

```text
Enter an odd diamond width (3-19): 7
   *
  * *
 *   *
*     *
 *   *
  * *
   *
```
