# Algorithm

1. Store each class as a tuple containing course, day, start, end, and room.
2. Compare each pair of classes.
3. If day matches and one starts before the other ends, report a conflict.
4. Display a no-conflict message if no overlap exists.
