# Objectives

- Represent course schedules using tuples.
- Detect time overlaps.
- Report conflicting course pairs.
