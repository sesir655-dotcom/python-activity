# Test Case

**Input / setup:** Python Monday 09:00-10:00; Mathematics Monday 09:30-10:30; Physics Monday 11:00-12:00; English Tuesday 09:00-10:00

**Expected output:**

```text
Timetable conflicts found:
Python conflicts with Mathematics on Monday.
```
