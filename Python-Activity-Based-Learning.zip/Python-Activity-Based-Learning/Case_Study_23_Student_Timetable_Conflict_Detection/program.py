classes = [
    ("Python", "Monday", 900, 1000, "Lab 1"),
    ("Mathematics", "Monday", 930, 1030, "Room 2"),
    ("Physics", "Monday", 1100, 1200, "Room 3"),
    ("English", "Tuesday", 900, 1000, "Room 4")
]

conflicts = []
for i in range(len(classes)):
    course1, day1, start1, end1, room1 = classes[i]
    for j in range(i + 1, len(classes)):
        course2, day2, start2, end2, room2 = classes[j]
        if day1 == day2 and start1 < end2 and start2 < end1:
            conflicts.append((course1, course2, day1))

if conflicts:
    print("Timetable conflicts found:")
    for course1, course2, day in conflicts:
        print(f"{course1} conflicts with {course2} on {day}.")
else:
    print("No timetable conflicts found.")
