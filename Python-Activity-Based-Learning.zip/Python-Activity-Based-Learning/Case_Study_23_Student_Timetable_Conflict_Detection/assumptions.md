# Assumptions

- Times use 24-hour HHMM integers.
- A class interval is treated as [start, end).
- Two classes conflict only when they are on the same day and their intervals overlap.
