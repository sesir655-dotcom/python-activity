# Student Timetable Conflict Detection

Check a proposed timetable for overlapping class periods and identify conflicts between courses.
