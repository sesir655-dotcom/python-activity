# Python Activity-Based Learning (ABL)

**Student name:** Lingam Sasank Venkat  
**Roll number:** 26000938  
**Branch:** CSM  
**Section:** 2

This repository contains 10 selected case studies from the faculty-provided Python ABL list. Each folder includes the problem statement, objectives, assumptions, algorithm, pseudocode, Python program, test case/output, and conclusion.

## Selected case studies
1. Case Study 2: Progressive Electricity Billing
2. Case Study 11: Examination Result and Grace-Mark Validation
3. Case Study 13: ATM Transaction Sequence Simulation
4. Case Study 14: Warehouse Inventory Reconciliation
5. Case Study 16: Multi-Day Water Tank Simulation
6. Case Study 23: Student Timetable Conflict Detection
7. Case Study 27: Advanced Numeric Pattern Generator
8. Case Study 29: Password Policy Validation Engine
9. Case Study 42: Student Marks Matrix Analysis
10. Case Study 53: Food Waste Monitoring System

## How to run
1. Install Python 3.
2. Open a terminal in a case-study folder.
3. Run `python program.py`.
4. Enter the sample inputs shown in `test_cases.md` where prompted.

**Note:** Tariff values, grace-mark rules, limits, and thresholds are sample assumptions for this academic exercise. Confirm any faculty-specific rules before final submission. Create flowchart images for each case study and add screenshots from your own execution before submitting.
