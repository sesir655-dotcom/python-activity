def energy_charge(units):
    if units <= 100:
        return units * 2.0
    elif units <= 200:
        return 100 * 2.0 + (units - 100) * 3.0
    return 100 * 2.0 + 100 * 3.0 + (units - 200) * 5.0

current = int(input("Enter current month's units: "))
previous = int(input("Enter previous month's units: "))

if current < 0 or previous < 0:
    print("Error: units cannot be negative.")
else:
    energy = energy_charge(current)
    surcharge = energy * 0.05
    rebate = 20 if current <= 100 else 0
    total = energy + 50 + surcharge - rebate
    print(f"Energy charge: Rs.{energy:.2f}")
    print(f"Fixed charge: Rs.50.00")
    print(f"Surcharge: Rs.{surcharge:.2f}")
    print(f"Rebate: Rs.{rebate:.2f}")
    print(f"Total bill: Rs.{total:.2f}")
    if current > previous:
        print(f"Usage increased by {current - previous} units.")
    elif current < previous:
        print(f"Usage decreased by {previous - current} units.")
    else:
        print("Usage is unchanged.")
