# Test Case

**Input / setup:** Current units = 250; previous units = 200

**Expected output:**

```text
Enter current month's units: 250
Enter previous month's units: 200
Energy charge: Rs.750.00
Fixed charge: Rs.50.00
Surcharge: Rs.37.50
Rebate: Rs.0.00
Total bill: Rs.837.50
Usage increased by 50 units.
```
