# Progressive Electricity Billing

Calculate a household's electricity bill using progressive consumption slabs, a fixed charge, surcharge, and rebate.
