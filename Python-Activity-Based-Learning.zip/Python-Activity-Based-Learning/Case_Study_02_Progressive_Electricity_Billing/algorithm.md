# Algorithm

1. Read current and previous consumption.
2. Validate that both readings are non-negative.
3. Calculate progressive energy charges by slab.
4. Add fixed charge and surcharge; apply the eligible rebate.
5. Display the bill and compare it with the previous month.
