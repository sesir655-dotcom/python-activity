# Assumptions

- First 100 units cost ₹2.00 per unit.
- Next 100 units cost ₹3.00 per unit.
- Units above 200 cost ₹5.00 per unit.
- Fixed charge is ₹50; surcharge is 5% of energy charges; rebate is ₹20 when consumption is at most 100 units.
