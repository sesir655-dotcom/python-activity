# Objectives

- Calculate energy charges across multiple slabs.
- Apply fixed charges, surcharge, and rebate.
- Compare the current bill with the previous month's bill.
