# Objectives

- Check several password rules.
- Explain which conditions fail.
- Display a final valid/invalid status.
