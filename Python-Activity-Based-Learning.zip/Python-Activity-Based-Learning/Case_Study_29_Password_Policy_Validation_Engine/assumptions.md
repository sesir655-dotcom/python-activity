# Assumptions

- Minimum length is 8.
- A password must contain uppercase, lowercase, digit, and special character.
- Three identical consecutive characters are prohibited.
- The substring 'password' is prohibited without regard to case.
