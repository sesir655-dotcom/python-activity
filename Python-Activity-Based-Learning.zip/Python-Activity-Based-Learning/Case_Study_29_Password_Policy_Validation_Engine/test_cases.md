# Test Case

**Input / setup:** Sample input = Pass123!

**Expected output:**

```text
Enter a sample password to check: Pass123!
Password: VALID
Note: This is a local demonstration; do not enter a real password.
```
