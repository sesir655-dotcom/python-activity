password = input("Enter a sample password to check: ")
failures = []

if len(password) < 8:
    failures.append("Must contain at least 8 characters.")
if not any(ch.isupper() for ch in password):
    failures.append("Must contain an uppercase letter.")
if not any(ch.islower() for ch in password):
    failures.append("Must contain a lowercase letter.")
if not any(ch.isdigit() for ch in password):
    failures.append("Must contain a digit.")
if not any(not ch.isalnum() for ch in password):
    failures.append("Must contain a special character.")
if any(password[i] == password[i+1] == password[i+2]
       for i in range(len(password) - 2)):
    failures.append("Must not contain 3 identical consecutive characters.")
if "password" in password.lower():
    failures.append("Must not contain the word 'password'.")

if failures:
    print("Password: INVALID")
    for item in failures:
        print("-", item)
else:
    print("Password: VALID")
print("Note: This is a local demonstration; do not enter a real password.")
