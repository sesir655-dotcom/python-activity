# Password Policy Validation Engine

Evaluate a sample password against length, character-category, repeated-character, and prohibited-substring rules.
