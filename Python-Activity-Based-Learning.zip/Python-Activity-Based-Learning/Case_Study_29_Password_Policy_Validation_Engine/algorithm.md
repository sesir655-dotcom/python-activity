# Algorithm

1. Read a sample password.
2. Check length and character categories.
3. Check for three identical consecutive characters.
4. Check prohibited substring.
5. Print every failed rule and final status.
