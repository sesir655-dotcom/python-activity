# Algorithm

1. Set capacity and initial level.
2. For each day, calculate level = previous level + inflow - outflow.
3. Report shortages or overflow and adjust the stored level to valid bounds.
4. Record the first day the level reaches 800 litres.
5. Display final level.
