# Multi-Day Water Tank Simulation

Track water levels over several days using inflow and outflow values, detect overflow or shortage, and find when a target level is reached.
