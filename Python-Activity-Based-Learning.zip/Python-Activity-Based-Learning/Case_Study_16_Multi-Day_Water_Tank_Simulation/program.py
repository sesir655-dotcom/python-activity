capacity = 1000
level = 400
target = 800
daily_flow = [(300, 150), (250, 100), (100, 250), (50, 100)]

first_target_day = None
print("Day | Inflow | Outflow | End level | Status")
for day, (inflow, outflow) in enumerate(daily_flow, start=1):
    level += inflow - outflow
    status = "Normal"
    if level > capacity:
        status = f"Overflow of {level - capacity} L"
        level = capacity
    elif level < 0:
        status = f"Shortage of {-level} L"
        level = 0
    print(f"{day:>3} | {inflow:>6} | {outflow:>7} | {level:>9} L | {status}")
    if level >= target and first_target_day is None:
        first_target_day = day

if first_target_day is None:
    print(f"Target level {target} L was not reached.")
else:
    print(f"Target level {target} L first reached on day {first_target_day}.")
print(f"Final tank level: {level} L")
