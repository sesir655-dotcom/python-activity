# Conclusion

The simulation updates water levels over time and detects whether a target level, overflow, or shortage occurs.
