# Test Case

**Input / setup:** Initial level 400 L; daily inflow/outflow: (300,150), (250,100), (100,250), (50,100)

**Expected output:**

```text
Day | Inflow | Outflow | End level | Status
  1 |    300 |     150 |       550 L | Normal
  2 |    250 |     100 |       700 L | Normal
  3 |    100 |     250 |       550 L | Normal
  4 |     50 |     100 |       500 L | Normal
Target level 800 L was not reached.
Final tank level: 500 L
```
