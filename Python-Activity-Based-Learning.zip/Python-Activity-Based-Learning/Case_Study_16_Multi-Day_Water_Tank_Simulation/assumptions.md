# Assumptions

- Tank capacity is 1,000 litres.
- Initial water is 400 litres.
- Daily inflow/outflow values are in litres.
- Water below zero is recorded as shortage; overflow above capacity is recorded and capped at capacity.
