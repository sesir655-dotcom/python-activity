# Objectives

- Update tank level each day.
- Detect overflow and shortage.
- Identify the first day the target level is reached.
