days = [
    ("Monday", 200, 185),
    ("Tuesday", 220, 190),
    ("Wednesday", 180, 175),
    ("Thursday", 210, 180)
]
limit = 10
total_prepared = 0
total_leftovers = 0

print("Food Waste Report (limit: 10%)")
for day, prepared, served in days:
    if prepared <= 0 or served < 0 or served > prepared:
        print(f"{day}: Invalid data")
        continue
    leftovers = prepared - served
    percentage = leftovers / prepared * 100
    total_prepared += prepared
    total_leftovers += leftovers
    status = "EXCEEDS LIMIT" if percentage > limit else "Within limit"
    print(f"{day}: prepared={prepared}, served={served}, leftovers={leftovers}, waste={percentage:.2f}% - {status}")

overall = total_leftovers / total_prepared * 100
print(f"Overall leftovers: {total_leftovers}")
print(f"Overall waste percentage: {overall:.2f}%")
