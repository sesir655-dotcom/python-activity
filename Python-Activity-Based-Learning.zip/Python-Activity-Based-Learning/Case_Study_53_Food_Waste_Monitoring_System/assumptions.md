# Assumptions

- Waste percentage = leftovers / prepared meals × 100.
- Acceptable waste limit is 10%.
- Prepared meals must be greater than zero and served meals cannot exceed prepared meals.
