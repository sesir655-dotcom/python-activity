# Algorithm

1. Store daily prepared and served counts.
2. Validate each record.
3. Calculate leftovers and waste percentage.
4. Flag records over 10%.
5. Calculate overall waste percentage.
