# Test Case

**Input / setup:** Monday 200/185; Tuesday 220/190; Wednesday 180/175; Thursday 210/180

**Expected output:**

```text
Food Waste Report (limit: 10%)
Monday: prepared=200, served=185, leftovers=15, waste=7.50% - Within limit
Tuesday: prepared=220, served=190, leftovers=30, waste=13.64% - EXCEEDS LIMIT
Wednesday: prepared=180, served=175, leftovers=5, waste=2.78% - Within limit
Thursday: prepared=210, served=180, leftovers=30, waste=14.29% - EXCEEDS LIMIT
Overall leftovers: 80
Overall waste percentage: 9.88%
```
