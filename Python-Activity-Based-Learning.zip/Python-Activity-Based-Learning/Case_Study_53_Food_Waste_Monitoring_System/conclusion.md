# Conclusion

The program calculates daily and overall food waste and highlights days that exceed the allowed threshold.
