# Food Waste Monitoring System

Compare meals prepared, meals served, and leftovers across several days; calculate waste percentages and flag days that exceed an acceptable limit.
