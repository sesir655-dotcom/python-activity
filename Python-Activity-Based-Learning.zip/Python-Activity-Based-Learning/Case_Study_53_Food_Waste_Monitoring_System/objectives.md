# Objectives

- Calculate leftovers.
- Calculate waste percentage for each day.
- Identify days exceeding the waste threshold.
