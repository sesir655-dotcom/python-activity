products = [
    ("Notebook", 50, 20, 35, 35),
    ("Pen", 100, 30, 95, 32),
    ("Folder", 25, 10, 20, 12)
]
target_stock = 20

print("Inventory Reconciliation Report")
for name, opening, received, dispatched, recorded in products:
    expected = opening + received - dispatched
    discrepancy = recorded - expected
    replenish = max(0, target_stock - recorded)
    status = "OK" if discrepancy == 0 else "DISCREPANCY"
    print(f"\nProduct: {name}")
    print(f"Expected closing stock: {expected}")
    print(f"Recorded closing stock: {recorded}")
    print(f"Difference (recorded - expected): {discrepancy}")
    print(f"Status: {status}")
    print(f"Replenishment to target {target_stock}: {replenish}")
