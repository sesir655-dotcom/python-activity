# Algorithm

1. Read product details and quantities.
2. Calculate expected closing stock.
3. Compare it with recorded closing stock.
4. Calculate discrepancy and target replenishment.
5. Print a reconciliation report.
