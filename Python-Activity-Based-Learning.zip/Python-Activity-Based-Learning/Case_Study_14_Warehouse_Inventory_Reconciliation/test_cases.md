# Test Case

**Input / setup:** Notebook (50, 20, 35, 35); Pen (100, 30, 95, 32); Folder (25, 10, 20, 12)

**Expected output:**

```text
Inventory Reconciliation Report

Product: Notebook
Expected closing stock: 35
Recorded closing stock: 35
Difference (recorded - expected): 0
Status: OK
Replenishment to target 20: 0

Product: Pen
Expected closing stock: 35
Recorded closing stock: 32
Difference (recorded - expected): -3
Status: DISCREPANCY
Replenishment to target 20: 0

Product: Folder
Expected closing stock: 15
Recorded closing stock: 12
Difference (recorded - expected): -3
Status: DISCREPANCY
Replenishment to target 20: 8
```
