# Assumptions

- The target stock for each product is 20 units.
- Expected closing stock = opening + received - dispatched.
- All quantities must be non-negative.
