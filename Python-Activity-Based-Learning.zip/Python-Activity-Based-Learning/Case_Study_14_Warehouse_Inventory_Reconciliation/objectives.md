# Objectives

- Calculate expected closing stock.
- Compare expected and recorded stock.
- Calculate replenishment quantities to meet a target.
