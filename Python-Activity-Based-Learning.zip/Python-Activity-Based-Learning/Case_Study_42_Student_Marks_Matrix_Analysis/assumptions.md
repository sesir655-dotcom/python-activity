# Assumptions

- Rows represent students and columns represent subjects.
- All marks are out of 100.
- The sample data contains valid marks.
