# Objectives

- Calculate row-wise totals.
- Calculate column-wise averages.
- Identify top performer and lowest-average subject.
