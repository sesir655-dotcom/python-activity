# Test Case

**Input / setup:** Asha [88,76,91]; Bharat [72,85,70]; Charan [95,89,84]

**Expected output:**

```text
Student totals:
Asha: 255/300
Bharat: 227/300
Charan: 268/300

Subject averages:
Python: 85.00
Maths: 83.33
Physics: 81.67
Top performer: Charan
Weakest-average subject: Physics
```
