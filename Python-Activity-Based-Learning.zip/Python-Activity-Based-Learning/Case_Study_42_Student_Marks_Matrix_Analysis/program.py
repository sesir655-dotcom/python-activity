students = ["Asha", "Bharat", "Charan"]
subjects = ["Python", "Maths", "Physics"]
marks = [
    [88, 76, 91],
    [72, 85, 70],
    [95, 89, 84]
]

totals = [sum(row) for row in marks]
averages = []
for col in range(len(subjects)):
    subject_total = 0
    for row in marks:
        subject_total += row[col]
    averages.append(subject_total / len(marks))

top_index = totals.index(max(totals))
weakest_index = averages.index(min(averages))

print("Student totals:")
for i, name in enumerate(students):
    print(f"{name}: {totals[i]}/300")
print("\nSubject averages:")
for i, subject in enumerate(subjects):
    print(f"{subject}: {averages[i]:.2f}")
print(f"Top performer: {students[top_index]}")
print(f"Weakest-average subject: {subjects[weakest_index]}")
