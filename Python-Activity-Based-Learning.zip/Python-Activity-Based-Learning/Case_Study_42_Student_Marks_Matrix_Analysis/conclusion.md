# Conclusion

The program uses nested lists and loops to summarize student performance by student and by subject.
