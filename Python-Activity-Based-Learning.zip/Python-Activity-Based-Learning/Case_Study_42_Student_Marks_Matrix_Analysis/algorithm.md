# Algorithm

1. Store marks in a nested list.
2. Calculate each row's total.
3. Calculate average for each column.
4. Find the student with the highest total.
5. Find the subject with the lowest average.
