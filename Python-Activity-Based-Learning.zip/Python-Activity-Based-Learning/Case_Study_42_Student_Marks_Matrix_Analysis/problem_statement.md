# Student Marks Matrix Analysis

Analyze a nested list of marks to calculate each student's total and each subject's average, then identify the top student and weakest-average subject.
